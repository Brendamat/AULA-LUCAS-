package Aula4;

public class ContaTest {
	
	public static void main (String args []) {
		Conta conta1= new Conta(1234.21);
		Conta conta2= new Conta(-12);
		System.out.println ("Valor da conta1: " +conta1.getBalanco());
		System.out.println ("Valor da conta2: "+conta2.getBalanco());
		
		conta2.Deposito(123.21);
		System.out.println("Valor da conta2 atualizado: "+conta2.getBalanco());
		
		conta1.saque(234);
		System.out.println("Valor da conta2 atualizado: "+conta1.getBalanco());
		conta2.saque(124);
		System.out.println("Valor da conta2 atualizado: "+conta2.getBalanco());
		
	}
}
