package Aula4;

import java.util.Scanner;

public class senac {

	String nomeCurso; 
	
	//Construtor da classe 
	
	public senac (String nome) {
		nomeCurso = nome;
	}
	
	public void setNomeCurso (String nome) {
		nomeCurso = nome; 
	}
	
	public String getNomeCurso () {
		return nomeCurso;
	}
	
	public void MostraMensagem ( ) {
		System.out.println ("Bem vindo ao curso: " + getNomeCurso ());
	}
}
