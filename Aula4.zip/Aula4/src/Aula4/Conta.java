package Aula4;

public class Conta {
	
	private double balanco;
	public Conta(double balancoInicial) {
		if (balancoInicial > 0.0) {
			balanco= balancoInicial;
		}
	} //fim construtor
	
	public void Deposito(double valor) {
		balanco= balanco+valor; //balanco+valor
	}
	
	public void saque (double valor) {
		if(valor <= balanco) {
			balanco= balanco - valor;
		}//fim if
		else
		{
			System.out.println("O saldo excede o valor na conta!!");
		}//fim else 
	}//fim metodo
	
	public double getBalanco() {
		return balanco;
		
	}

}
