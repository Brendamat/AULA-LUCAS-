package Aula4;

import java.util.Scanner;

public class senacTest {
	
	public static void main (String args []) {
		Scanner input= new Scanner (System.in);
		System.out.print("Digite o curso");
		String nome= input.nextLine();
		senac objeto= new senac (nome);
		System.out.println (objeto.getNomeCurso()); //get puxa o valor
		
		System.out.print("Digite o novo curso");
		nome= input.nextLine();
		objeto.setNomeCurso("nome"); //set atribui valor 
		objeto.MostraMensagem();
		
	}

}
