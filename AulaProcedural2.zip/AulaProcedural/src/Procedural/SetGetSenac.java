package Procedural;

public class SetGetSenac { //SET define GET recupera 
	
	private String nomeCurso;
	
	public void setNomeCurso(String valor) {
		nomeCurso= valor;	
	}
	public String getNomeCurso() {
		return nomeCurso;
	}
	public void MostrarMensagem() {
		
		System.out.println("Nome do curso: "+ getNomeCurso());
	}

}
