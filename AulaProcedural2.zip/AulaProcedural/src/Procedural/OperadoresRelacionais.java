package Procedural;

import java.util.Scanner;
public class OperadoresRelacionais
{

	public static void main(String args[])
	{
		 Scanner input = new Scanner (System.in);
		 int num1, num2;
		 System.out.print("Digite o primeiro valor:");
		 num1= input.nextInt ();
		 System.out.print("Digite o segundo valor: ");
		 num2= input.nextInt ();
		 
	} //fim main
} //fim classe
