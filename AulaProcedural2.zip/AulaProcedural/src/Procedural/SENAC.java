package Procedural;

import java.util.Scanner;

public class SENAC {
	
	public void MostrarMensagem(String s) {
		System.out.println("Bem vindo ao curso:"+s); // Systen.out. para sair na tela
		System.out.printf("Bem vindo ao curso:%s\n", s); // \n para pular linha; e o %s referente a string
	}// fim m�todo MostrarMensagem 
	
	public static void main(String args[]) {
		Scanner input = new Scanner (System.in); // Systen.in para entrada
		SENAC objeto= new SENAC ();
		String nomeCurso;
		System.out.print("Digite o nome:");
		nomeCurso= input.nextLine();
		objeto.MostrarMensagem(nomeCurso);
	}

}
