package Procedural;

import java.util.Scanner;
public class SetGetSenacTEST {
	
	public static void main (String args[]) {
		SetGetSenac objeto = new SetGetSenac();
		Scanner input = new Scanner (System.in); 
		String curso; 
		System.out.println("Curso: "+objeto.getNomeCurso());
		curso = input.nextLine();
		objeto.setNomeCurso(curso);
		System.out.println("Curso:"+objeto.getNomeCurso());
	}

}
