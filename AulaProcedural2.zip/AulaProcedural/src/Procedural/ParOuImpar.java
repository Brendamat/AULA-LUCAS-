package Procedural;

public class ParOuImpar {

}
