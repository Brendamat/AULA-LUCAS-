package matrizes;

import java.util.Scanner; 
public class MatrizesTest {
	
	public static void main (String args[]) {
		Scanner input =  new Scanner (System.in);
			Matrizes teste= new Matrizes ();
			double matriz [] [] = new double [2][2];
			for (int linha=0; linha < matriz [0].length; linha++) {
				for (int coluna=0; coluna < matriz [1].length; coluna++) {
					System.out.printf("Digite o valor na linha %d e coluna %d:\n",linha, coluna);
					matriz[linha][coluna]=input.nextDouble();
				} //for da coluna
			} //for da linha 
			
	System.out.println("**imprimindo Matriz**");		
	for (int linha=0; linha < matriz [0].length; linha++) {
		for (int coluna=0; coluna < matriz [1].length; coluna++) {
			double aux=matriz[linha][coluna];
			System.out.printf("O valor armazenado na linha %d ecoluna %d =%.2f\n",
					linha,coluna,aux); 
		}//fim for coluna		
	}//fim for linha
	
	System.out.println("**imprimindo Matriz**");		
	for (int linha=0; linha < matriz [0].length; linha++) {
		for (int coluna=0; coluna < matriz [1].length; coluna++) {
			double aux=matriz[linha][coluna];
			System.out.printf("%.0f ", aux);
		}//fim for coluna		
		System.out.println();
	}//fim for linha
	
	//chamando o atualizar 
	matriz= teste.atualizar(matriz, 0, 1);
	
	System.out.println("**imprimindo Matriz**");		
	for (int linha=0; linha < matriz [0].length; linha++) {
		for (int coluna=0; coluna < matriz [1].length; coluna++) {
			double aux=matriz[linha][coluna];
			System.out.printf("%.0f ", aux);
		}//fim for coluna		
		System.out.println();
	}//fim for linha
	
  } //fim do main
}//fim classe 
