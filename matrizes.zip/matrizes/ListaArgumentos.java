package matrizes;

public class ListaArgumentos {
	
	public double media (double... numeros) {
		double total=0.0;
		for(double numero:numeros) {
			total= total + numero;
			
		}//fim for
		return total /numeros.length;
	}//fim media 

}
