package matrizes;

public class Matrizes {
	public Matrizes () {
		
	}
	public double [][] atualizar (double mat [][], int linha, int coluna){
		mat[linha][coluna]=0.0;
		return mat;
	}

}
