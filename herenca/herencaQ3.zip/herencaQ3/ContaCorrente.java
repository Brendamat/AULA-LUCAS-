package herencaQ3;

public class ContaCorrente extends ContaBancaria{
	private double limiteChequeEspecial;
	private String numeroCartaoDebito;
	public ContaCorrente (double limiteChequeEspecial, String numeroCartaoDebito,
			String titular, double saldoInicial) {
		super(titular, saldoInicial);
		this.limiteChequeEspecial= limiteChequeEspecial;
		this.numeroCartaoDebito= numeroCartaoDebito;
		}
	public double getLimiteChequeEspecial() {
		return limiteChequeEspecial;
	}
	public void setLimiteChequeEspecial(double limiteChequeEspecial) {
		this.limiteChequeEspecial = limiteChequeEspecial;
	}
	public String getNumeroCartaoDebito() {
		return numeroCartaoDebito;
	}
	public void setNumeroCartaoDebito(String numeroCartaoDebito) {
		this.numeroCartaoDebito = numeroCartaoDebito;
	}
	
	public double Saque (double valorSaque) {
		double retornar=0.0;
		if(valorSaque < this.getsaldo()) {
			retornar= valorSaque;
			super.setsaldo(super.getsaldo()- valorSaque);
		}
		else if (valorSaque <= super.getsaldo() + this.getLimiteChequeEspecial()) {
			retornar = valorSaque;
			double qtdValorJuros= valorSaque - super.getsaldo();
			qtdValorJuros= qtdValorJuros * 1.07;
			super.setsaldo(qtdValorJuros * -1);
		}
		return retornar; 	
	}

}
