package herencaQ3;

public class ContaBancaria {
	private String titularConta;
	private Double saldo;
	
	public ContaBancaria (String titular, Double saldoInicial) {
		this.titularConta= titular;
		this.saldo= saldoInicial;
	}
	
	public void settitularConta (String titular) {
		this.titularConta= titular;
	}
	public String gettitularConta () {
		return this.titularConta;
	}
	
	public void setsaldo (double valor) {
		this.saldo= valor;
	}
	public double getsaldo () {
		return this.saldo;
	}
	
	public void deposito (double valor) {
		this.saldo= this.saldo + valor;
	}
	
	public double Saque (double valorSaque) {
		double retornar=0.0;
		if(valorSaque < this.getsaldo()) {
			retornar= valorSaque;
			this.saldo= this.saldo - valorSaque;
		}
		return retornar; 		
	}
	
	public double transferir (String numConta, double valorTransfere) {
		double transferido=0.0;
		if(valorTransfere <=this.getsaldo()) {
			transferido= valorTransfere;
			this.saldo= this.saldo - valorTransfere;
		}
		return transferido;
	}
	

}
